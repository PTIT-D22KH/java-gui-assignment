/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai2;

/**
 *
 * @author P51
 */
public class Main {
    public static void main(String[] args) {
        VeHinh a = new VeHinh();
        a.setVisible(true);
    }
}
